simpletable
===========

Python module to provide simple HTML table creation without third-party libraries.
